@javax.xml.bind.annotation.XmlSchema(namespace = "http://jawxs.ibm.tutorial/jaxws/orderprocess")
package com.ibm.jaxws.tutorial.service.client;
